% NLOPT_LD_LBFGS_NOCEDAL: original NON-FREE L-BFGS code by Nocedal et al. (NOT COMPILED)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_LBFGS_NOCEDAL
  val = 10;
