#include <stdio.h>
int main(void) { printf("Hello world.\n"); return 0; }
